-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2014 at 03:41 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pharmacy`
--
CREATE DATABASE IF NOT EXISTS `pharmacy` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pharmacy`;

-- --------------------------------------------------------

--
-- Table structure for table `medicineproduct`
--

CREATE TABLE IF NOT EXISTS `medicineproduct` (
  `Product_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Product_Name` varchar(20) NOT NULL,
  `Product_Desc` varchar(50) NOT NULL,
  `Quantity_Per_Unit` int(10) NOT NULL,
  `Prod_Unit_Price` int(10) NOT NULL,
  `Prod_Stock` int(10) NOT NULL,
  PRIMARY KEY (`Product_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `medicineproduct`
--

INSERT INTO `medicineproduct` (`Product_ID`, `Product_Name`, `Product_Desc`, `Quantity_Per_Unit`, `Prod_Unit_Price`, `Prod_Stock`) VALUES
(2, 'Tiki-Tiki Star', 'Baby Vitamins', 1, 12, 399),
(3, 'BioFlu', 'Fever', 1, 10, 1098),
(4, 'Robust', 'Mens Health', 1, 200, 500),
(5, 'Mefenamic', 'Headache', 1, 13, 2000),
(7, 'Biogesic', 'Fever, Headache, Body ache', 1, 4, 1000),
(8, 'Neozep', 'Colds, Runny Nose', 1, 4, 1501),
(12, 'Alaxan', 'Body Pain', 1, 10, 1562),
(14, 'Robitussin', 'Cough', 1, 15, 467),
(16, 'Loperamide', 'LBM', 1, 6, 400),
(17, 'Buscopan', 'Abdominal Spasm', 1, 15, 95),
(18, 'Metropolol', 'High-Blood', 1, 15, 642),
(22, 'Norvasc', 'Highblood Maintenance', 10, 30, 500),
(23, 'Paracetamol', 'sdffslkgjdslfkjdfsl', 10, 5, 100),
(24, 'ABC', 'dsfsdfd', 2, 10, 98);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE IF NOT EXISTS `orderdetails` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Order_Med_ID` int(10) NOT NULL,
  `Product_ID` int(10) NOT NULL,
  `Order_Quantity` int(3) NOT NULL,
  `Order_Amount` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `Order_Med_ID`, `Product_ID`, `Order_Quantity`, `Order_Amount`) VALUES
(1, 0, 12, 0, 0),
(2, 0, 8, 0, 0),
(3, 0, 7, 0, 0),
(4, 0, 7, 0, 0),
(5, 0, 3, 2, 10),
(6, 0, 2, 1, 12),
(7, 0, 19, 0, 15),
(8, 0, 19, 3, 15),
(9, 0, 8, 4, 4),
(10, 0, 14, 4, 15),
(11, 0, 19, 4, 15),
(12, 0, 19, 44, 15),
(13, 0, 19, 122, 15),
(14, 0, 17, 4, 15),
(15, 0, 18, 4, 15),
(16, 0, 19, 4, 15),
(17, 0, 7, 1, 4),
(18, 0, 5, 2, 13),
(19, 0, 4, 3, 200),
(20, 0, 3, 4, 10),
(21, 0, 2, 5, 12),
(22, 0, 17, 5, 15),
(23, 1, 19, 5, 15),
(24, 5, 19, 4, 15),
(25, 6, 17, 0, 15),
(26, 6, 18, 0, 15),
(27, 7, 18, 7, 15),
(28, 7, 19, 5, 15),
(29, 8, 5, 2, 13),
(30, 8, 4, 3, 200),
(31, 9, 18, 5, 15),
(32, 10, 2, 16, 12),
(33, 11, 2, 100, 12),
(34, 12, 19, 50, 15),
(35, 13, 16, 100, 6),
(36, 14, 17, 3, 15),
(37, 15, 14, 30, 15),
(38, 16, 19, 12, 15),
(39, 16, 18, 10, 15),
(40, 17, 2, 1, 12),
(41, 18, 14, 3, 15),
(42, 18, 3, 2, 10),
(43, 19, 17, 2, 15),
(44, 20, 24, 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ordermedicine`
--

CREATE TABLE IF NOT EXISTS `ordermedicine` (
  `Order_Med_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Cust_Address` varchar(50) NOT NULL,
  `Cust_Name` varchar(20) NOT NULL,
  `Order_Med_Qty` int(4) NOT NULL,
  `Order_Total_Amt_Purchase` int(4) NOT NULL,
  `Order_Date` date NOT NULL,
  PRIMARY KEY (`Order_Med_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `ordermedicine`
--

INSERT INTO `ordermedicine` (`Order_Med_ID`, `Cust_Address`, `Cust_Name`, `Order_Med_Qty`, `Order_Total_Amt_Purchase`, `Order_Date`) VALUES
(1, 'wewr31', 'qweqe', 1, 1830, '2013-10-18'),
(2, 'rioja', 'rosi', 3, 180, '2013-10-18'),
(3, 'alangcao', 'aldren', 5, 730, '2013-10-18'),
(7, 'QC', 'Rosi', 2, 0, '2013-10-19'),
(12, '153 P. Jacinto', 'Alfred', 1, 750, '2013-10-19'),
(13, '153 P. Jacinto St. Caloocan City', 'Alfred', 1, 600, '2013-10-19'),
(14, 'QC', 'Celine', 1, 45, '2013-10-19'),
(15, 'Pasig', 'March', 1, 450, '2013-10-19'),
(17, 'manila', 'kulas', 1, 12, '2013-10-19'),
(18, 'manila', 'tes', 2, 65, '2013-10-19'),
(19, 'Tondo, Manila', 'Arlen', 1, 30, '2013-10-19'),
(20, 'werewr', 'sdfsdf', 1, 20, '2013-10-19');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `Supplier_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Supplier_Name` varchar(20) NOT NULL,
  `Supplied_Date` date NOT NULL,
  `Supplier_Address` varchar(50) NOT NULL,
  `Supplier_Contact` int(11) NOT NULL,
  `Product_ID` int(10) NOT NULL,
  PRIMARY KEY (`Supplier_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Supplier_ID`, `Supplier_Name`, `Supplied_Date`, `Supplier_Address`, `Supplier_Contact`, `Product_ID`) VALUES
(1, 'UNILAB', '2013-10-11', 'Manila City', 2147483647, 0),
(50, 'RiteMed', '2013-10-31', 'Makati', 9981877, 3),
(51, 'UNILAB', '2013-10-09', 'Manila', 9981877, 2),
(52, 'Unilab', '2013-10-08', 'Marikina', 789, 0),
(53, 'Unilab', '2013-10-08', 'Marikina', 789, 0),
(54, 'Unilab', '2013-10-01', 'ParanaqueCity', 745, 0),
(55, 'Ritemed', '2013-10-03', 'Makati', 456, 0),
(56, 'Janssen', '2013-10-08', 'Quezon City', 789, 0),
(57, 'Unilab', '2013-10-09', 'Makati', 456, 16),
(58, 'Pfizer', '2013-10-02', 'Quezon', 456, 17),
(59, 'Pfizer', '2013-06-04', 'Navotas', 452, 18),
(60, 'Pfizer', '2013-10-01', 'Navotas', 452, 19),
(61, 'Wyeth', '2013-10-16', 'US', 456, 5),
(63, 'Glaxosmithkine', '2013-10-19', 'Muntinlupa', 4278714, 20),
(64, 'Unilab', '2013-10-19', 'qc', 455467675, 21),
(65, 'Glaxosmithkine', '2013-10-09', 'Magallanes', 4278714, 22),
(66, 'Ritemed', '2013-10-19', 'QC', 45687658, 23),
(67, 'sdfsdgf', '2013-10-19', 'sdfdfg', 23345345, 24);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Employee_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Dob` date NOT NULL,
  `Sex` varchar(10) NOT NULL,
  `Access_Type` varchar(10) NOT NULL,
  PRIMARY KEY (`Employee_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Employee_ID`, `Username`, `Password`, `First_Name`, `Last_Name`, `Address`, `Dob`, `Sex`, `Access_Type`) VALUES
(10, 'elise', '123456', 'Elise', 'Sibal', 'Quezon City', '2013-04-17', 'Female', ''),
(15, 'waw', '21232f29', 'Rosiliza', 'RIoja', 'Marikina City', '1993-02-23', 'Female', 'admin'),
(16, 'admin', '73acd9a5972130b75066c82595a1fae3', 'Rosiliza', 'Rioja', 'Marikina City', '1993-02-23', 'Female', 'admin'),
(17, 'celine', 'e10adc3949ba59abbe56e057f20f883e', 'Celine Mae', 'Toledo', 'Quezon City', '1993-05-03', 'Female', 'employee'),
(19, 'mitchie', '81dc9bdb52d04dc20036dbd8313ed055', 'Mitchie', 'Tabirao', 'Santol', '2013-10-03', 'Female', 'employee'),
(20, 'rosirioja', 'e10adc3949ba59abbe56e057f20f883e', 'Rosiliza', 'Rioja', 'Marikina City', '1993-02-23', 'Female', 'employee'),
(21, 'John', '81dc9bdb52d04dc20036dbd8313ed055', 'John', 'Doe', 'Ohio, USA', '1987-10-07', 'Male', 'admin'),
(22, 'kat', '3d7f65f5dcc8ef953f7d9a06f2477cc4', 'Katrina', 'Yabu', 'Taguig', '2013-09-17', 'Female', 'employee'),
(23, 'kim', '574e3ce197265298a8d59004043998db', 'Kim', 'Lleno', 'Rizal', '2009-10-08', 'Male', 'employee'),
(24, 'abc', '900150983cd24fb0d6963f7d28e17f72', 'Arlen', 'Canlas', 'Tondo Manila', '2013-10-23', 'Male', 'employee');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
